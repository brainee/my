﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231058',
        hpageid: '231058',
        bizType: 'DIY',
        viewType: 'selftravelorderlist',
        title: '自由行订单'
    });
});