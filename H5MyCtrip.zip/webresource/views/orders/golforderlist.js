define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231079',
        hpageid: '231079',
        bizType: 'Golf',
        viewType: 'golforderlist',
        title: '高尔夫订单'
    });
});