﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231034',
        hpageid: '231034',
        bizType: 'Cruise',
        viewType: 'cruiseorderlist',
        title: '邮轮订单'
    });
});