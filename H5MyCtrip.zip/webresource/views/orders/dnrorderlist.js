define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '',
        hpageid: '',
        bizType: 'Dnr',
        viewType: 'dnrorderlist',
        title: '美食订餐订单'
    });
});