﻿define(['commonlist', 'MyCtripModel'], function (CommonListFactory, MyCtripModel) {
    return CommonListFactory.getInstance({
        pageid: '231057',
        hpageid: '231057',
        bizType: 'Activity',
        viewType: 'localeventorderlist',
        title: '当地玩乐订单'
    });
});