﻿/// <summary>
/// 酒店点评 creator:caofu; createtime:2013-11-09
///</summary>
define(['UIRadioList', 'cUtilValidate', 'CommonStore', 'cLocalStorage', 'MyCtripStore', 'MyCtripModel', 'cPageView', 'cUtility', 'cGuiderService'], function (cui, Validate, commonStore, cStorage, myCtripStore, myCtripModel, basePageView, cUtility, widgetFactory) {
    var userStore = commonStore.UserStore.getInstance(), userInfo = userStore.getUser();
    //参数store  slh
    var orderListHotelId = myCtripStore.CustomerHotelOrderId.getInstance();
    var hotelCommetSubmitModel = myCtripModel.WaitForCommentOrderListSubmitModel.getInstance();
    var View = basePageView.extend({
        pageid: '212053',
        hpageid: '212053',
        onHide: function () {
            this.hideLoading();
            this.scrollRadioList && this.scrollRadioList.hide();
            hotelCommetSubmitModel.abort();
        },
        onCreate: function () {
            //this.injectHeaderView();
        },
        onShow: function () {
            this.bShowMenu = cPublic.ctripMenu({ show: true, buName: 'order' });
            
            var self = this;
            this.headerview.set({
                title: "点评酒店",
                back: true,
                view: this,
                tel: null,
                home: null,
                events: {

                }
            });
            this.headerview.show();
         },
        onLoad: function () {
            this.showLoading();
            this.render();
            this.updatePage();
            this.updateHead();
            this.turning();
        },
        chooseServerType: function () {
            if (!this.list) {
                var el = this.$("#serverType-val");
                var demodata = [{
                    key: 10,
                    id: '商务出差'
                }, {
                    key: 30,
                    id: '家庭出游'
                }, {
                    key: 70,
                    id: '夫妻/情侣出游'
                }, {
                    key: 40,
                    id: '和朋友/同事出游'
                }, {
                    key: 50,
                    id: '独自出游'
                }, {
                    key: 60,
                    id: '代人预订'
                }, {
                    key: 0,
                    id: '其他'
                }];
                this.list = new cui({
                    //数据模型
                    datamodel: {
                        title: "请选择出行目的",
                        data: demodata
                    },
                    displayNum: 5,
                    onClick: function (data) {
                        el.html(data.id).attr('data-serverType', data.key);
                        this.hide();
                    }
                });
            }
            this.list.show();
        },
        loginCheck: function () {
            //未登录或者非会员不能浏览当前页面
            userInfo = userStore.getUser();
            if (!userInfo || !userInfo.UserID || !userInfo.Auth || userInfo.IsNonUser) {
                this.forward('#account/login');
                return;
            }
        },
        render: function () {
            //修改酒店标题    slh
            this.$el.html(_.template(this.tpl)({
                data: {
                    title: orderListHotelId.getAttr('hotelName')
                }
            }));
        },
        events: {
            'click .newstar': 'changeHeart',
            'click #submitReSearch': 'submitReSearch',
            'click #serverType': 'chooseServerType'
        },
        updatePage: function () {
            this.turning();
            this.hideLoading();
        },
        backAction: function () {
            //跟store返回url  slh
            var backUrl = orderListHotelId.getAttr('url') || "";
            if (backUrl) {
                this.jump(backUrl);
            } else {
                this.jump("/webapp/myctrip/index");
            }
        },
        changeHeart: function (e) {
            var ele = e.target || e.srcElement;
            var perwidth = $(".newstar").width() / 5;
            if (ele.tagName.toLowerCase() == "i") {
                $(ele).css("width", e.offsetX - e.offsetX % perwidth + perwidth);
            }
            else {
                $(ele).find("i").css("width", e.offsetX - e.offsetX % perwidth + perwidth);
            }
        },
        submitReSearch: function () {
            var data = this.neatenData();
            var _this = this;
            if (data) {
                _this.showLoading();
                hotelCommetSubmitModel.setParam({
                    "content": data.Content,
                    "faclPt": data.FaclPoint,
                    "hotelId": data.HotelId,
                    "identityText": "",
                    "oid": data.OrderId,
                    "raAtPt": data.RaAtPoint,
                    "ratPt": data.RatPoint,
                    "servPt": data.ServPoint,
                    "ver": 0,
                    "subject": "",
                    "userIdentity": Number(data.UserIdentity)
                });
                hotelCommetSubmitModel.excute(function (d) {
                    if (d.res) {
                        _this.hideLoading();
                        _this.showToast('提交成功，感谢您的参与，谢谢！');
                        setTimeout(function () {
                            _this.backAction();
                        }, 200);
                    }
                    else {
                        _this.hideLoading();
                        _this.showToast(d.msg);
                    }
                }, function () {
                    _this.hideLoading();
                    _this.showToast('抱歉，评论提交失败！ ');
                }, false, this);
            }
        },
        neatenData: function () {
            //var sanitation = $('#sanitation').val().trim(), periphery = $('#periphery').val().trim(), service = $('#service').val().trim(), facility = $('#facility').val().trim(), selServerType = $('#selServerType').val(), txtComment = $('#txtComment').val().trim();
            // 修改参数 slh
            var perwidth = $(".newstar").width() / 5;
            var sanitation = parseInt($('#sanitation').css('width'), 10) / perwidth, periphery = parseInt($('#periphery').css('width'), 10) / perwidth,
            service = parseInt($('#service').css('width'), 10) / perwidth, facility = parseInt($('#facility').css('width'), 10) / perwidth,
            selServerType = $('#serverType-val').attr('data-serverType'), txtComment = $('#txtComment').val().trim();
            if (+sanitation == 0) {
                this.showToast('请给“房间卫生”打分，谢谢！');
                return;
            }
            if (+periphery == 0) {
                this.showToast('请给“周边环境”打分，谢谢！');
                return;
            }
            if (+service == 0) {
                this.showToast('请给“酒店服务”打分，谢谢！');
                return;
            }
            if (+facility == 0) {
                this.showToast('请给“设备设施”打分，谢谢！');
                return false;
            }
            if (!selServerType) {
                this.showToast('请选择出行目的！');
                return false;
            }
            if (txtComment.length < 20) {
                this.showToast('请写出您对酒店的感受，不少于20个字');
                return;
            }
            if (txtComment.length > 500) {
                this.showToast('您对酒店的感受颇深，洋洋洒洒已超500字，再精简下吧');
                return;
            }
            userInfo = userStore.getUser();
            return {
                RatPoint: sanitation,
                RaAtPoint: periphery,
                ServPoint: service,
                FaclPoint: facility,
                UserIdentity: selServerType,
                Content: txtComment,
                OrderId: orderListHotelId.getAttr('oid'),
                HotelId: orderListHotelId.getAttr('hotelId'),
                UserId: userInfo.UserID,
                Logintoken: userInfo.LoginToken
            };
        },
        updateHead: function () {
            var self = this;
            //对HeaderView设置数据
            self.headerview.set({
                title: '点评酒店',
                back: true,
                view: self,
                events: {
                    returnHandler: $.proxy(function () {
                        this.backAction();
                    }, this),
                    homeHandler: $.proxy(function () {
                        this.jump('/html5/');
                    }, this)
                }
            });
            this.headerview.show();
        }
    });
    return View;
});