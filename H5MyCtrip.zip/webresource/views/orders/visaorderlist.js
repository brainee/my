﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231059',
        hpageid: '231059',
        bizType: 'Visa',
        viewType: 'visaorderlist',
        title: '签证订单'
    });
});