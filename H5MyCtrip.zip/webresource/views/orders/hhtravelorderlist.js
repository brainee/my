// HHTravel订单
define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231078',
        hpageid: '231078',
        bizType: 'HHTravel',
        viewType: 'hhtravelorderlist',
        title: 'HHTravel订单 '
    });
});