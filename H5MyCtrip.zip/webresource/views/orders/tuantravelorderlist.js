﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231012',
        hpageid: '231012',
        bizType: 'Vacation',
        viewType: 'tuantravelorderlist',
        title: '旅游订单'
    });
});