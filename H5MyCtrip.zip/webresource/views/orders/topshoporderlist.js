﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231061',
        hpageid: '231061',
        bizType: 'TopShop',
        viewType: 'topshoporderlist',
        title: '高端商户订单'
    });
});