// 机场巴士订单
define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231077',
        hpageid: '231077',
        bizType: 'AirportBus',
        viewType: 'airportbusorderlist',
        title: '机场巴士订单'
    });
});