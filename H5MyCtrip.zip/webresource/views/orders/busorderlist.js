﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231035',
        hpageid: '231035',
        bizType: 'QiChe',
        viewType: 'busorderlist',
        title: '汽车票订单'
    });
});