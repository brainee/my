﻿// 非会员有用到这个页面
define(['cPageView', 'cGuiderService', 'cMemberService', 'myctripCommon', 'cUtilCommon'], function (cPageView, Guider, Member, MyctripCommon, cUtilCommon) {
    var View = cPageView.extend({
        pageid: '231033',
        hpageid: '231033',
        loginStatus: 0,//判断当前登录状态0：未登录 1：会员登录 2：老的非会员 3：新的非会员
        //非会员新方案[酒店，团购]
        noneUserList: ['/hotelorderlist', '/tuanorderlist'],
        onCreate: function () {
            var html = '',
                additional = '',
                order = null,
                orderTypeList = MyctripCommon.getOrderTypeList();

            html = '<ul class="cui-select-view ordercenter-list" id="orderList">';
            for (var i = 0, len = orderTypeList.length; i < len; i++) {
                order = orderTypeList[i];
                if (cUtilCommon.isInApp && order.name === '火车票订单') {
                    additional = '<span class="placeholder">支持12306订单</span>';
                } else {
                    additional = '';
                }
                html += '<li class="' + order.classname + '" data-href="' + order.url + '">' + additional + order.name + '</li>';
            }
            html += '</ul>';

            this.$el.html(html);
        },
        events: {
            "click li": "jumplist"
        },
        onShow: function () {
            var self = this,
                elements = this.$el.find("li");

            self.loginStatus = MyctripCommon.checkLogin();

            this.headerview.set({
                title: '选择订单类型',
                back: true,
                view: self,
                events: {
                    returnHandler: function () {
                        Guider.apply({
                            callback: function () {
                                Lizard.goTo("/webapp/myctrip/index");
                            }, hybridCallback: function () {
                                if (isShowSlideMenu) {
                                    Lizard.goTo("/webapp/myctrip/index");
                                } else {
                                    Guider.jump({
                                        targetModel: 'app',
                                        module: 'myctrip'
                                    });
                                }
                            }
                        })
                    }
                }
            });
            self.headerview.show();

            if (self.loginStatus != 1) {
                self.$el.find(".o-all").hide();
            }

            elements.filter('.on').removeClass('on');
            if (self.referrer && self.referrer.match(/orders\/\w+/)) {
                elements.filter('[data-href*="' + self.referrer + '"]').addClass('on');
            }
        },
        jumplist: function (e) {
            var self = this,
                url = $(e.currentTarget).closest("li").data("href") || "",
                hasurl = function (name) {
                    return (url.indexOf(name) >= 0);
                };
            self.loginStatus = MyctripCommon.checkLogin();
            var isNewUnlogin = self.loginStatus === 0 || self.loginStatus === 2;//新的非会员
            var isOldUnlogin = self.loginStatus === 0 || self.loginStatus === 3;//老的非会员
            var isJoinNewUnlogin = false;
            for (var i = 0; i < self.noneUserList.length; i++) {
                if (hasurl(self.noneUserList[i])) {
                    isJoinNewUnlogin = true;
                }
            }
            Guider.apply({
                callback: function () {
                    if (isJoinNewUnlogin && isNewUnlogin) {
                        Lizard.goTo(Lizard.appBaseUrl + 'accounts/unlogincheck?from=' + encodeURIComponent(Lizard.appBaseUrl + url));//手机号码查询页
                    } else if (!isJoinNewUnlogin && isOldUnlogin) {
                        Lizard.goTo(Lizard.appBaseUrl + "accounts/login?from=" + encodeURIComponent(Lizard.appBaseUrl + url));//老的非会员订单查询页
                    } else {
                        Lizard.goTo(Lizard.appBaseUrl + url);
                    }
                }, hybridCallback: function () {
                    if (self.loginStatus === 0) {
                        var hasNoUserList = !(hasurl("travelticketorderlist") || hasurl("topshop") || hasurl("airportbusorderlist"));
                        Member.memberLogin({
                            isShowNonMemberLogin: hasNoUserList,
                            callback: function (data) {
                                if (data) {
                                    Lizard.goTo(Lizard.appBaseUrl + url);
                                }
                            }
                        });
                    } else {
                        Lizard.goTo(Lizard.appBaseUrl + url);
                    }
                }
            });
        }
    });
    return View;
});