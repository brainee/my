define(['commonlist', 'cGuiderService'], function (CommonListFactory, Guider) {
    return CommonListFactory.getInstance({
        pageid: '231062',
        hpageid: '231062',
        bizType: 'VacationInsurance',
        viewType: 'insureorderlist',
        title: '保险订单'
    });
});