﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231011',
        hpageid: '231011',
        bizType: 'Car',
        viewType: 'carorderlist',
        title: '用车订单'
    });
});