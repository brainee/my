﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '214017',
        hpageid: '214017',
        bizType: 'Tuan',
        viewType: 'tuanorderlist',
        title: '团购订单'
    });
});