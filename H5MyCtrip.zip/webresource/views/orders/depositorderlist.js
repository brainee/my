define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '',
        hpageid: '',
        bizType: 'Deposit',
        viewType: 'depositorderlist',
        title: '存款证明订单'
    });
});