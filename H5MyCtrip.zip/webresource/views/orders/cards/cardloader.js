define('cardloader', ['basecard', 'flightcard', 'topshopcard', 'hotelcard', 'vacationcard', 'carcard', 'piaocard', 'activitycard', 'taxicard', 'tuancard', 'insurecard', 'cruisecard', 'qichecard', 'lipincard', 'traincard', 'diycard', 'sceneryhotelcard', 'visacard', 'airbuscard', 'golfcard', 'hhtravelcard', 'mallcard', 'globalbuycard', 'depositcard', 'dnrcard'], function (BaseCard) {
	BaseCard.init();
	return BaseCard;
});