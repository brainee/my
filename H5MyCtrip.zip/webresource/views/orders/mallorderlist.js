// 礼遇商城订单
define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '',
        hpageid: '',
        bizType: 'Mall',
        viewType: 'mallorderlist',
        title: '礼遇商城订单'
    });
});