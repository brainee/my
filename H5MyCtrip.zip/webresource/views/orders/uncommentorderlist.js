define(['commonlist', 'cUtilCommon', 'cGuiderService'], function (CommonListFactory, cUtilCommon, Guider) {
    return CommonListFactory.getInstance({
        pageid: '231013',
        hpageid: '231013',
        unionType: 'AwaitReview',
        viewType: 'uncommentorderlist',
        title: '待评价订单',
        bCustomizeHead: true,
        hasVacation: false,
        tipContent: '成功点评旅游订单赠500积分！',
        onShow: function (self) {
            if (!self.isOnline) {
                self.headerview.set({
                    title: '待评价订单',
                    back: true,
                    view: self,
                    events: {
                        returnHandler: function () {
                            Guider.apply({ callback: function () {
                                self.jump('/webapp/myctrip');
                            }, hybridCallback: function () {
                                Guider.backToLastPage();
                            }
                            });
                        }
                    }
                });
            }
            self.hasVacation = false;
        },
        onAfterRender: function (self) {//页面渲染完成后显示tips，3秒后隐藏。
            if (self.hasVacation) {
                self._showTip();
                setTimeout($.proxy(self._hideTip, self), 3000);
            }
        }
    });
});