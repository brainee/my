﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231010',
        hpageid: '231010',
        bizType: 'SceneryHotel',
        viewType: 'sceneryhotelorderlist',
        title: '酒店+景点订单'
    });
});