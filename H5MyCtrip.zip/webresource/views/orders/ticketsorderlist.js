﻿define(['commonlist'], function (CommonListFactory) {
    return CommonListFactory.getInstance({
        pageid: '231056',
        hpageid: '231056',
        bizType: 'Piao',
        viewType: 'ticketsorderlist',
        title: '景点门票订单'
    });
});