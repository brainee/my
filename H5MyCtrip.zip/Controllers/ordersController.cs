﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace myctirp.Controllers
{
    public class ordersController : Controller
    {
        //
        // GET: /orders/
        public ActionResult airportbusorderlist()
        {
            return View();
        }
        public ActionResult allorders()
        {
            return View();
        }
        public ActionResult sceneryhotelorderlist()
        {
            return View();
        }
        public ActionResult busorderlist()
        {
            return View();
        }
        public ActionResult carorderlist()
        {
            return View();
        }
        public ActionResult cruiseorderlist()
        {
            return View();
        }
        public ActionResult flightorderlist()
        {
            return View();
        }
        public ActionResult globalbuyorderlist()
        {
            return View();
        }
        public ActionResult golforderlist()
        {
            return View();
        }
        public ActionResult hhtravelorderlist()
        {
            return View();
        }
        public ActionResult hotelcomment()
        {
            return View();
        }
        public ActionResult hotelorderlist()
        {
            return View();
        }
        public ActionResult insureorderlist()
        {
            return View();
        }
        public ActionResult localeventorderlist()
        {
            return View();
        }
        public ActionResult mallorderlist()
        {
            return View();
        }
        public ActionResult ordertypelist()
        {
            return View();
        }
        public ActionResult search()
        {
            return View();
        }
        public ActionResult searchresult()
        {
            return View();
        }
        public ActionResult selftravelorderlist()
        {
            return View();
        }
        public ActionResult taxiorderlist()
        {
            return View();
        }
        public ActionResult ticketsorderlist()
        {
            return View();
        }
        public ActionResult topshoporderlist()
        {
            return View();
        }
        public ActionResult trainorderlist()
        {
            return View();
        }
        public ActionResult travelticketorderlist()
        {
            return View();
        }
        public ActionResult tuanorderlist()
        {
            return View();
        }
        public ActionResult tuantravelorderlist()
        {
            return View();
        }
        public ActionResult uncommentorderlist()
        {
            return View();
        }
        public ActionResult unpaidorderlist()
        {
            return View();
        }
        public ActionResult unuseorderlist()
        {
            return View();
        }
        public ActionResult visaorderlist()
        {
            return View();
        }
        public ActionResult unloginorderlist()
        {
            return View();
        }
        public ActionResult depositorderlist()
        {
            return View();
        }
        public ActionResult dnrorderlist()
        {
            return View();
        }
    }
}
