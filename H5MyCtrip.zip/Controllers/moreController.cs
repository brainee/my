﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace myctirp.Controllers
{
    public class moreController : Controller
    {
        public ActionResult index()
        {
            return View();
        }

    }
}
